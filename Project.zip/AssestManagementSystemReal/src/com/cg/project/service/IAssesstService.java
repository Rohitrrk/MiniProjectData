package com.cg.project.service;

import com.cg.project.bean.AssestBean;
import com.cg.project.bean.UsersBean;

public interface IAssesstService {

	public boolean validateLogin(UsersBean bean);
	
	public int addAssestDetails(AssestBean assetBean);
}
