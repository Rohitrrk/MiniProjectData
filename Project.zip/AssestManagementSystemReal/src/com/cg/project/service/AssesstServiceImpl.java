package com.cg.project.service;

import com.cg.project.bean.AssestBean;
import com.cg.project.bean.UsersBean;
import com.cg.project.dao.AssesstDaoImpl;
import com.cg.project.dao.IAssesstDao;


public class AssesstServiceImpl implements IAssesstService{

	IAssesstDao dao = new AssesstDaoImpl() ;
		
		
		
		@Override
		public boolean validateLogin(UsersBean bean) 
		{
			// TODO Auto-generated method stub
			return dao.validateLogin(bean);
		}



		@Override
		public int addAssestDetails(AssestBean assetBean) {
		
			return dao.addAssestDetails(assetBean);
		}

		

		



		

		

	
	

}
