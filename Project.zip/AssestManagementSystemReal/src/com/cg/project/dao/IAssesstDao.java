package com.cg.project.dao;

import com.cg.project.bean.AssestBean;
import com.cg.project.bean.UsersBean;

public interface IAssesstDao {

	public boolean validateLogin(UsersBean bean);

	public int addAssestDetails(AssestBean assetBean);

	

	


	


}
