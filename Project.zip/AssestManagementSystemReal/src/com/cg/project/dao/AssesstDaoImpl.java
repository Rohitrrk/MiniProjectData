package com.cg.project.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.project.bean.AssestBean;
import com.cg.project.bean.UsersBean;
import com.cg.project.dbutil.Dbutil;

public class AssesstDaoImpl implements IAssesstDao {

	Connection con ;
	Statement st ;
	PreparedStatement pst;
	
	@Override
	public boolean validateLogin(UsersBean bean) {
		
		
		String message = null;
		boolean flag = false;
		
		try {
			con = Dbutil.getConnection();
			String sql = "Select userName, userPassword FROM User_Master";
			st = con.createStatement();
			ResultSet 	rs = st.executeQuery(sql);
			while(rs.next())
			{
				
				String user_name = rs.getString(1);
				String pass = rs.getString(2);
				
				
				if(user_name.equals(bean.getUserName()) && pass.equals(bean.getUserPassword()))
				{
					flag = true;
				
				}
					
				
			}
			
			
			
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return flag;
	}
	@Override
	public int addAssestDetails(AssestBean assetBean) {
	
		int row = 0;
		try
		{
			con = Dbutil.getConnection();
			String insert = "INSERT INTO Asset Values(?,?,?,?,?)";
			pst = con.prepareStatement(insert);
	
			pst.setInt(1, assetBean.getAssetId());
			pst.setString(2, assetBean.getAssetName());
			pst.setString(3, assetBean.getAssetDes());
			pst.setInt(4, assetBean.getQuantity());
			pst.setString(5, assetBean.getStatus());
			
			row = pst.executeUpdate();
			
			
			
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return row;
	}
	


	
	

}
