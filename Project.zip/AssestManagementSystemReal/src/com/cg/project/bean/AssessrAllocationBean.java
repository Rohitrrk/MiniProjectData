package com.cg.project.bean;

import java.sql.Date;

public class AssessrAllocationBean {
	
	
	private int allocationId;
	private int assetId;
	private int Empno;
	private Date Allocation_date;
	private Date Release_date;
			
	

}
