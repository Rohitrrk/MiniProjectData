package com.cg.project.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.project.bean.AssestBean;
import com.cg.project.bean.UsersBean;
import com.cg.project.service.AssesstServiceImpl;

public class AssestManagementMain {
	
	static AssesstServiceImpl service = new AssesstServiceImpl();
	static UsersBean userbean = new UsersBean();
	static AssestBean assetBean = new AssestBean();
	static int ch = 0;
	static Scanner scanner=  new Scanner(System.in);
	public static void main(String[] args)
	{
		
		System.out.println("********  Login Page *******");
		System.out.println(" User Type : \n"
				+ "1.Admin \n"
				+ "2.Manager \n"
				+ "3.Exit");
	
		ch = scanner.nextInt();
		scanner.nextLine();
		
		
		System.out.println("Enter the username :");
		String name = scanner.nextLine();
		System.out.println("Enter the Passowrd :");
		String password = scanner.next();
		
		userbean.setUserName(name);
		userbean.setUserPassword(password);
	
		if(service.validateLogin(userbean))
		{
			System.out.println("Login Success !!!!!!");
			switch(ch)
			{
			case 2:
				//For Mananger
			
				System.out.println("Enter Choice :\n"
						+ "1.Raise Request \n"
						+ "2.View Status");
				
				ch = scanner.nextInt();
				switch(ch)
				{
				case 1:
					//Raise Request 
				
					
					
					break;
				case 2:
					//View Status
					
					
					
					break;
					
				default :
					System.out.println("Invalid Choice !!!");
				}
				
				
				
				
				break;
				
			case 1:
				//For Admin 
				do
				{
				System.out.println("Enter Choice :\n"
						+ "1.Add/Modify Asset Details  \n"
						+ "2.View all request raised \n"
						+ "3.Approve/reject request \n"
						+ "4.Logout");
				
				
				ch=scanner.nextInt();
				switch(ch)
				{
				case 1:
					//Add Asset Details
					
					addAssestDetails();
					break;
					
				case 2:
					//Modify Asset Details
					
					System.out.println("Abhi nhi kiya");
					break;
					
				case 3 :
					//Approve / reject request
					
					
					break;
					
				case 4:
					//logout
					System.out.println("Logged Out !!");
					System.exit(0);
					
				default:
					System.out.println("Invalid Choice !!!");
				}
				
				break;
				}
				while(ch != 4);
			}
			
			
			
			
		}
		else
		{
			System.out.println("Invalid User Name or Password !!!");
		}
		
		
		scanner.close();
		
	}

	private static void addAssestDetails() {
		System.out.println("AssetId : \n");
		int assestid = scanner.nextInt();
		System.out.println("Enter AssetName");
		String assetName = scanner.nextLine();
		
		System.out.println("Enter Asset Description ");
		String assetDes  = scanner.nextLine();
		
		System.out.println("Enter Quantity");
		int quantity = scanner.nextInt();
		
		
		
		assetBean.setAssetId(assestid);
		assetBean.setAssetName(assetName);
		assetBean.setAssetDes(assetDes);
		assetBean.setQuantity(quantity);
		
		
		int res = service.addAssestDetails(assetBean);
		if(res == 1)
		{
			
		}
		else
		{
			
		}
		
		
	}

	
}
